# crlib

crlib - is a small utility library for the YaPB bot and tools.

When initially bot was written as PODbot in 2000 year, there was awful support for STL in different compilers, so it was decision to not use STL inside bot project.

This is not true anymore, so this library will be deprecated as much as possible while converting the bot code to STL. However this is highly unlikely in near future. So this "wheel" will be here for some time.
